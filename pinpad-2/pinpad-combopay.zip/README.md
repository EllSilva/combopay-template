# pinpad-combopay
A tecnologia agora no ponto de venda


https://brunocriacoes.github.io/pinpad-combopay/

# Versão Online
https://pinpad.combopay.com.br 
