import Vue from './library/vue.js'
const App = new Vue({
    el: '#app',
    data: {
        offset_config: -320,
        valor: '00,00',
        operacao: 0,
        tipo_parcela: 1,
        disabled: false,
        offset_alert: -100,
        message: '',
        pinpad_messages: '',
        pinpad_error: '',
        pinpad_success: '',
        max_parcelas: [ { id: 1, text: 'A VISTA' } ],
        configure: {
            marketplace_id: null,
            seller_id: null,
            publishable_key: null,
            serial_port_list: 'AUTO',
        },
        error: {
            message: '',
            status: false
        }
    },
    watch: {
        operacao(val) {
            if( val == 1 ) {
                this.tipo_parcela = 1
                this.disabled = true
            } else {
                this.disabled = false
            }
        },
        valor( val ) {

            let valor = val
            let parcelas = [1,2,3,4,5,6,7,8,9,10,11,12]

            valor = valor.replace('.','')
            valor = valor.replace(',','.')
            valor = parseFloat( valor )

            parcelas = parcelas.map( (item, key) =>  valor / (key+1) )
            parcelas = parcelas.filter( x => x >= 5 )
            this.max_parcelas = parcelas.map( (item, id) =>  ({id: id+1 , text: id == 0 ? 'A VISTA' : `PARCELADO ${id+1}X`}) )
            
            console.log( parcelas.length )
        }
    },
    methods: {
        onopen(event) {
            console.log('websocket conectado com sucesso')
            console.log( event )
        },
        onclose(event) {
            console.log( event )
            this.error.status = true
            this.error.message ='conexão com websocket cancelada'
        },
        onmessage(event) {
            let data = JSON.parse(event.data)
            this.pinpad_messages = data.message
            if(data.mid == 'endOfTransaction') {
                setTimeout(() => {
                    this.pinpad_error = ''
                    this.pinpad_success = ''
                }, 10000);
            }
            if(data.mid == 'paymentSuccessful') {
                // this.cancelar()
                this.pinpad_success = 'VENDA REALIZADA COM SUCESSO!'
            }
            if(data.mid == 'paymentFailed') {
                this.pinpad_error = data.history[data.history.length -1].response_message.replace(/\d/gi,'')
            }
            console.log( event )
        },
        onerror(event) {
            console.log( event )
            this.error.status = true
            this.error.message ='algo inesperado aconteceu'
        },
        error(event) {
            console.log( event )
            this.error.status = true
            this.error.message ='erro ao conectar o websocket'
        },
        start_ws() {
            try {
                // globalThis.ws = new WebSocket('ws://fb67078fd696.ngrok.io')
                globalThis.ws = new WebSocket('ws://localhost:1337')
                globalThis.ws.onopen = this.onopen
                globalThis.ws.onclose = this.onclose
                globalThis.ws.onmessage = this.onmessage
                globalThis.ws.onerror = this.onerror
            } catch (event) {
                this.error(event)
            }
        },
        valor_in_centavos: valor => valor.replace(/\D/gi,''),
        tipo_opercacao( numero ) {
            let arr = [
                "credit",
                "debit",
                "credit_with_installments",
                "voucher",
            ]
            return arr[parseInt(numero)] || "credit"         
        },
        vender() {
            let playload = {
                mid: 'charge',
                marketplaceId: this.configure.marketplace_id,
                sellerId: this.configure.seller_id,
                publishableKey: this.configure.publishable_key,
                serialPort: this.configure.serial_port_list,
                paymentType: this.tipo_parcela == '1' ? this.tipo_opercacao( this.operacao ) : this.tipo_opercacao(3),
                valueInCents: this.valor_in_centavos( this.valor ),
                numberOfInstallments: this.tipo_parcela,
                metadata: null,
                referenceId: null,    
            }
            console.log(playload)
            globalThis.ws.send( JSON.stringify(playload) )
        },
        cancelar() {
            this.valor = '00,00'
            this.operacao = 0
            this.tipo_parcela = 1
            this.pinpad_messages = ''
        },
        config_save() {
            localStorage.setItem('PINPAD_CONFIG', JSON.stringify(this.configure))
            this.message = 'Configurações Atualizadas!'
            this.offset_alert = 20
            setTimeout( () => {
                this.offset_alert = -100
            }, 3000 )
        },
        config_info() {
            return JSON.parse(localStorage.getItem('PINPAD_CONFIG') || '{}')
        },
        format_val() {
            let val = this.valor            
            val = val.replace('.', '')
            val = val.replace(/\D/gi, '')
            val = val ? val : 0
            val = `${parseInt(val)}` ?? '0'
            switch (val.length) {
                case 0:
                    val = '00,00'                   
                    break;
                case 1:
                    val = val.replace(/(\d{1})/gi, '00,0$1')                    
                    break;
                case 2:
                    val = val.replace(/(\d{2})/gi, '00,$1')                    
                    break;
                case 3:
                    val = val.replace(/(\d{1})(\d{2})/gi, '0$1,$2')                    
                    break;
                case 4:
                    val = val.replace(/(\d{2})(\d{2})/gi, '$1,$2')                    
                    break;
                case 5:
                    val = val.replace(/(\d{3})(\d{2})/gi, '$1,$2')                    
                    break;    
                case 6:
                    val = val.replace(/(\d{1})(\d{3})(\d{2})/gi, '$1.$2,$3')                    
                    break;            
                default:
                    val = val.replace(/(\d{1})(\d{3})(\d{2})(.*)/gi, '$1.$2,$3')
                    break;
            }
            
            this.valor = val
        },

    },
    mounted() {
        this.configure = { ...this.configure, ...this.config_info() }
        this.start_ws()
    }
})

